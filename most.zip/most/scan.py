import shodan

# api here
SHODAN_API_KEY = 'TX4ihDAxrxXJYusOPXz4lwVhRNuXvo0S'

api = shodan.Shodan(SHODAN_API_KEY)

try:
    with open('idk.txt', 'w') as f: # ok đây là file python3 để lấy list ip từ shodan
    	# search query here
        query = 'Server: Boa/0.93.15 port:80'
        page = 1
        results = api.search(query, page=page)
        total_results = results['total']
        print('Total results:', total_results)

        while (page - 1) * 100 < total_results:
            results = api.search(query, page=page)
            for result in results['matches']:
                ip = result['ip_str']
                f.write(ip + '\n')
            page += 1
            print('Processed', page * 100, 'results')

except shodan.APIError as e:
    print('Error: %s' % e)

